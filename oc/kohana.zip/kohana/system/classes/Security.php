<?php defined('SYSPATH') OR die('No direct script access.');

class Security extends Kohana_Security {}
