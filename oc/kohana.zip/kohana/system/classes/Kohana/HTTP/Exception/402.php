<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_402 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 402 Payment Required
	 */
	protected $_code = 402;

}
