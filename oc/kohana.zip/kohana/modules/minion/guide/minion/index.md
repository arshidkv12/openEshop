# Minion

Minion is a simple command line task runner.